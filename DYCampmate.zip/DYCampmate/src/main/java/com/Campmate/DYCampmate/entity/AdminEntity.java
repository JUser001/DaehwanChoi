package com.Campmate.DYCampmate.entity;

import jakarta.persistence.*;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

import java.time.LocalDateTime;

@Entity
@Table(name = "admins", uniqueConstraints = {
        @UniqueConstraint(columnNames = "email")
})
@Getter
@Setter
public class AdminEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;  // int(15) → Integer

    @Setter
    @Column(nullable = false, length = 255, unique = true)
    private String email;

    @Column(nullable = false, length = 255)
    private String password;

    @Column(nullable = false, length = 255)
    private String name;

    @Column(nullable = false, name = "camping_style", length = 255)
    private String campingStyle;

    @Column(nullable = false, name = "camping_background", length = 255)
    private String campingBackground;

    @Column(nullable = false, name = "camping_type", length = 255)
    private String campingType;

    @Column(name = "create_dt")
    private LocalDateTime createDt;

    // 기본 생성자
    public AdminEntity() {}

    // 전체 생성자
    public AdminEntity(String email, String password, String name, String campingStyle,
                 String campingBackground, String campingType, LocalDateTime createDt) {
        this.email = email;
        this.password = password;
        this.name = name;
        this.campingStyle = campingStyle;
        this.campingBackground = campingBackground;
        this.campingType = campingType;
        this.createDt = createDt;
    }



}