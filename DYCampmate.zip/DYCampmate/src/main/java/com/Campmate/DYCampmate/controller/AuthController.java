package com.Campmate.DYCampmate.controller;

import com.Campmate.DYCampmate.dto.LoginRequestDTO;
import com.Campmate.DYCampmate.service.AdminService;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
//@CrossOrigin(origins = "http://localhost:3000") // React 개발 서버 포트에 맞게 설정 config 패키지 내 이미 설정함
public class AuthController
{
    private final AdminService adminService;

    public AuthController(AdminService adminService) {
        this.adminService = adminService;
    }

    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestBody LoginRequestDTO loginDto) {
        boolean isValid = adminService.validateLogin(loginDto.getEmail(), loginDto.getPassword());

        if (isValid) {
            return ResponseEntity.ok("로그인 성공");
        } else {
            return ResponseEntity.status(401).body("이메일 또는 비밀번호가 올바르지 않습니다.");
        }
    }
}
