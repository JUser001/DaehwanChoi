package com.Campmate.DYCampmate.dto;

import lombok.Getter;

@Getter
public class LoginRequestDTO {
    private String email;
    private String password;

}
