package com.Campmate.DYCampmate.dto;

import lombok.Data;
import lombok.Getter;

import java.time.LocalDateTime;

@Data
public class AdminDTO {

    private String email;
    private String password;
    private String name;
    private String campingStyle;
    private String campingBackground;
    private String campingType;
    private LocalDateTime createDt;


}
