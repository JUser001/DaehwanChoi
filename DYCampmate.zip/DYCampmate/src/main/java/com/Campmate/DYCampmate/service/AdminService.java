package com.Campmate.DYCampmate.service;

import com.Campmate.DYCampmate.dto.AdminDTO;
import com.Campmate.DYCampmate.entity.AdminEntity;
import com.Campmate.DYCampmate.repository.AdminRepo;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class AdminService {

    private final AdminRepo adminRepository;
    private final BCryptPasswordEncoder passwordEncoder;
//    private final PasswordEncoder passwordEncoder;

    public AdminService(AdminRepo adminRepository, BCryptPasswordEncoder passwordEncoder) {
        this.adminRepository = adminRepository;
        this.passwordEncoder = passwordEncoder;
    }

    //로그인 검사
    public boolean validateLogin(String email, String password) {
        Optional<AdminEntity> adminOpt = adminRepository.findByEmail(email);
        if (adminOpt.isPresent()) {
            AdminEntity admin = adminOpt.get();
            return admin.getPassword().equals(password);
        }
        return false;
    }











    public AdminEntity registerAdmin(AdminDTO dto) {
        if (adminRepository.existsByEmail(dto.getEmail())) {
            throw new IllegalArgumentException("이미 등록된 이메일입니다.");
        }

        AdminEntity admin = new AdminEntity();
        admin.setEmail(dto.getEmail());
        admin.setPassword(passwordEncoder.encode(dto.getPassword()));
        admin.setName(dto.getName());
        admin.setCampingStyle(dto.getCampingStyle());
        admin.setCampingBackground(dto.getCampingBackground());
        admin.setCampingType(dto.getCampingType());
        admin.setCreateDt(LocalDateTime.now());

        return adminRepository.save(admin);
    }

    public Optional<AdminEntity> findByEmail(String email) {
        return adminRepository.findByEmail(email);
    }
}
