package com.Campmate.DYCampmate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DyCampmateApplication {

	public static void main(String[] args) {

		SpringApplication.run(DyCampmateApplication.class, args);
		//9216095f-de04-49ef-a4b4-489760ca6fac
	}

}
